#Don't be a thief by stealing other's Hardwork, it took time and effort to make this repo.
#Respect my work by not making any changes here.

START_TEXT = "أرسل لي أي ملف للبدء."

FORCE_SUB_TEXT = "من أجل استخدام هذا الروبوت ، عليك الانضمام إلى القناة الأم الخاصة بي."

CHANNEL_LINK = "https://t.me/DroneBots"

SUPPORT_LINK = "https://t.me/TeamDrone"

info_text = "This bot is developed by @MaheshChauhan\n\nWritten in python library TELETHON.\n\nBot by : @DroneBots\nSupport : @TeamDrone\n\nV1.4"   

help_text = """**v1.4**

•`تشفير` - ترميز الفيديو الخاص بك إلى تنسيق lib أو دقة مختلفة

•`HEVC ضغط` - ضغط خسارة ضئيل

•`FAST ضغط` - ضغط سريع جدا وفعال

•`Convert` - تغيير التنسيقات أو استخراج الصوت من أي فيديو

•`Rename` - إعادة تسمية أي ملف ، التمديد غير مطلوب

•`SSHOTS` - إنشاء 10 لقطات من الفيديو الخاص بك

•`Trim` - قص مقاطع الفيديو الخاصة بك"""

source_text = "**Deploy your own bot**"

DEV = "https://t.me/MaheshChauhan"

spam_notice = "This bot is hosted on heroku, and hence can just run one process at a time.Spamming the bot or encoding adult videos will lead you to a ban."

JPG = "LOCAL/video_convertor.jpg"

JPG0 = 'https://telegra.ph/file/d98c559b56ef884ef3bad.jpg'

JPG2 = "LOCAL/20211215_165751.jpg"

JPG3 = "LOCAL/PicsArt_12-16-08.57.15.jpg"

JPG4 = "LOCAL/20211219_000258.jpg"

